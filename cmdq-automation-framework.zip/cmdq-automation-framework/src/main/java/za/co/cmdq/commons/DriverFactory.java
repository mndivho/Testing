package za.co.cmdq.commons;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
public class DriverFactory {


    public WebDriver driver;
    public Properties prop;
    private String scenarioPath;
    private static Logger log = LogManager.getLogger(DriverFactory.class.getName());
    Map<String, Map<String, String>> outerMap = new HashMap<>();
    ArrayList<Map> arrayList = new ArrayList();


    public  WebDriver initializeDriver() throws IOException {

        prop = new Properties();
        FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources/environmentVariables.properties");
        prop.load(fis);
        String browserName = "chrome";
        switch (browserName)
        {
            case "chrome":
                System.setProperty(prop.getProperty("chrome"), prop.getProperty("chromePath"));
                driver = new ChromeDriver();
                driver.get("https://ui.uatwamly.co.za/");
                driver.manage().window().maximize();
                break;

            case "firefox":
                System.setProperty(prop.getProperty("firefox"), prop.getProperty("geckoPath"));
                driver = new FirefoxDriver();
                driver.get("https://ui.uatwamly.co.za/");
                break;

            case "IE":
                System.setProperty(prop.getProperty("IE"), prop.getProperty("IEPath"));
                driver = new FirefoxDriver();
                driver.get("https://ui.uatwamly.co.za/");
                break;
            default:throw new RuntimeException("Invalid browser");
        }
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        return driver;
    }

}
