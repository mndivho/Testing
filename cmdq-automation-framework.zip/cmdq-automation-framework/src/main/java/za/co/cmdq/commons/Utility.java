package za.co.cmdq.commons;

import org.openqa.selenium.WebElement;

public class Utility
{
    public static void waitForElement(WebElement element, int seconds)
    {
        try {
            element.wait(seconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void clickElementByExpath()
    {

    }
    public void scrollToElementByExpath()
    {

    }
    public void extract()
    {

    }
}
