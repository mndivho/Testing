package za.co.cmdq.pageobjects;

public class pageObjects
{
    private String username()
    {
        return "//input[@class='MuiInputBase-input MuiOutlinedInput-input']";
    }
    private String pass(String text)
    {
        return "";
    }
}
