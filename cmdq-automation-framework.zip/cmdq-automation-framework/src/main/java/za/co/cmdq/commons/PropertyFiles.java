package za.co.cmdq.commons;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

    public class PropertyFiles {
    public String propFileName = "src/main/resources/test-drivers.properties";
    protected InputStream inputStream;
    protected Properties props = new Properties();

    public Properties getPropValues() {

        try {
            inputStream = new FileInputStream(propFileName);

            if (inputStream != null) {
                props.load(inputStream);
            } else {
                throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return props;
    }
}

