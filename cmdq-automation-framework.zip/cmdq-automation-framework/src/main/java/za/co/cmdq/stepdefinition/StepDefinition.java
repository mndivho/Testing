package za.co.cmdq.stepdefinition;

import io.cucumber.java.en.Given;
import za.co.cmdq.pageobjects.LoginPage;

public class StepDefinition extends LoginPage {

    @Given("user navigates to Facebook")
    public  void testing(){
        username.sendKeys();

        String n = username.getText();
        //assert n == "": thnjghn
    }
}
