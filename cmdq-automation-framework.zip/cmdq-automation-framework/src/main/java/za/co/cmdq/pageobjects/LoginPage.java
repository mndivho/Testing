package za.co.cmdq.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import za.co.cmdq.commons.DriverFactory;

public class LoginPage  extends DriverFactory {

    @FindBy(how = How.ID, using = "elementid")
    public WebElement username;

    @FindBy(how = How.XPATH, using = "//*[@id=\"sign-in-user-6\"]")
    public WebElement password;
    }






