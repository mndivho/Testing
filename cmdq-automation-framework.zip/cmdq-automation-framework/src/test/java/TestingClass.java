import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import za.co.cmdq.commons.DriverFactory;
import za.co.cmdq.commons.Utility;
import za.co.cmdq.pageobjects.pageObjects;

import java.io.IOException;

public class TestingClass {


    @Test
    public void launchingBrowser() throws IOException {
        DriverFactory driverFactoryA = new DriverFactory();
        DriverFactory driverFactoryB = new DriverFactory();
        pageObjects element = new pageObjects();

        WebDriver driver = driverFactoryA.initializeDriver();
        //driver.findElement(By.xpath(element.username()));
        //WebElement element = driver.findElement(By.xpath("//*[@id=\"sign-in-user-6\"]"));
        //element.isDisplayed();
//        while (!username.isDisplayed()){
//
//
//        }
        //Utility.waitForElement(element, 100);
    }
}
